package com.dicoding.flutter_ditonton_dicoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

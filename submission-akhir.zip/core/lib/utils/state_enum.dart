enum RequestState { Empty, Loading, Loaded, Error }

const POPULAR_MOVIES_ROUTE = '/popular-movie';
const TOP_RATED_MOVIE_ROUTE = '/top-rated-movie';
const MOVIE_DETAIL_ROUTE = '/detail';
const SEARCH_MOVIE_ROUTE = '/search-movie';
const ABOUT_ROUTE = '/about';
